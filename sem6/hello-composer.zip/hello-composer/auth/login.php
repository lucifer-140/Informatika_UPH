<?php
require '../vendor/autoload.php';

use Uph\Hello\Twig;

$twig = Twig::make(_DIR_ . '/templates');

session_start();

if ($_POST) {
    if ($_POST['username'] === 'user' && $_POST['password'] === 'pass') {
        $_SESSION['login'] = true;
        header('Location: index.php');
        die();
    }
    echo $twig->render('login.html.twig', ['error' => 'Login salah']);
    die();
}

echo $twig->render('login.html.twig');