package day11.tugas.OCP;

import java.util.Date;

public interface OrderViewer {
    void printOrder(); 
    void showOrder();
}
