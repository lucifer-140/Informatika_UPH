package day11.tugas.LSP;

public interface OrderViewer {
    void printOrder();
    void showOrder();
}
