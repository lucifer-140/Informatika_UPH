package day11.tugas.DIP;

public interface OrderPrinter { 
    void printOrder();
}