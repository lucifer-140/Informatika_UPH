package day11.tugas.DIP;

public interface OrderDisplayer {
    void showOrder();
}
