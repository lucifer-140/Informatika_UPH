package day11.tugas.SRP;

import java.util.ArrayList;
import java.util.List;

public class OrderHistory {
    
    public List<Order> getDailyHistory() {
        
        return new ArrayList<>();
    }

    public List<Order> getMonthlyHistory() {
        return new ArrayList<>();
    }
}
