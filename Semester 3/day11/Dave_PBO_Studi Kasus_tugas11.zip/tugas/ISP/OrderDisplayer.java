package day11.tugas.ISP;

public interface OrderDisplayer {
    void showOrder();
}
