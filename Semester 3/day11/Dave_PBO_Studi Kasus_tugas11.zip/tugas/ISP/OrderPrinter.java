package day11.tugas.ISP;

public interface OrderPrinter { 
    void printOrder();
}